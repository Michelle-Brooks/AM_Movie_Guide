<?php
//////////////////////////////////////////////////////////////////////
//                                                                  //
//   Copyright: Appplebite Media. (except where noted)              //
//   Author: Michelle Brooks (except where noted)                   //
//   Contact: http://www.applebitemedia.com/index.php?pid=contact   // 
//                                                                  //
//////////////////////////////////////////////////////////////////////

class Redirect {
    public static function to($location = null) {
        if($location){
            if(is_numeric($location)) {
                switch ($location) {
                case 404:
                    header('HTTP/1.0 404 Not Found');
                    include 'includes/errors/404.php';
                    exit();
                    break;
                }
            }
            header('Location: ' . $location);
            exit();
        }
    }
}
?>