<?php
//////////////////////////////////////////////////////////////////////
//                                                                  //
//   Copyright: Appplebite Media. (except where noted)              //
//   Author: Michelle Brooks (except where noted)                   //
//   Contact: http://www.applebitemedia.com/index.php?pid=contact   // 
//                                                                  //
//////////////////////////////////////////////////////////////////////

include 'classes/Gallery.php';
?>

<div class='container fade-in' style='margin-top: 15px;'>
    <span class='highlight' style='float: right; padding-top: 2%;'>Today is: <?php echo date('l, F jS Y - h:i a') ?></span>
    <h1><span style='font-size: 90%; color: #999;'><span class='highlight'> ( <?php echo $md, $gterm, $cterm, $yterm, $mterm, $ttlm, $actorname, $directorname, $newest, $seen ?> ) </span>  <smaller>Movies: ( <?php echo $gtotals ?> ) Total</smaller></span></h1>

<?php
while ($row = $gallery->fetch(PDO::FETCH_ASSOC)) {
    extract($row);
    $sawit = $row['Have_Seen'];
    $zero = false;
    if ($sawit != $zero) {
        $sawim = '';
    } else {
        $sawim = '<a class="sawit_box" data-toggle="tooltip" data-placement="auto" title="List all UNWATCHED movies." href="index.php?watched=Not Watched"><i class="far fa-eye-slash"></i></a>';
    }

    if ($i == 0) {
        echo "<div class='row' style='margin-left: 5px; margin-top: 20px; width: 100%;'>";
    }

    $addplus = preg_replace('/\s+/', '+', $row['Movie_Title']);
    $someth = str_replace('#', '_', $addplus);
    $addtoo = htmlspecialchars($someth, ENT_QUOTES, 'UTF-8');
    $maindir = str_replace(' ', '_', $row['Main_Dir']);
    ?>

        <div class="col-md-3" style="display: block;  border-radius: 6px;">
            <div class="" align="center" style="display: inline-block; height: 100%; width: 100%; margin-bottom: 20px;">

    <?php
    if ($row['Movie_Image'] == '') {
        echo "<div style='display: flex; height: 300px; margin-bottom: 15px; align='center'><br><div style='position: absolute; left: 10px; top: 15px; z-index: 99999 !important;'><a class='btn btn-outline-secondary btn-sm' data-toggle='tooltip' data-placement='auto' title=' Edit Movie Info ' href='index.php?pid=emov&Movie_Id=", $row['Movie_Id'], "'><i class='fas fa-plus-circle' style='font-size: 14px;'></i></a></div><img style='width: 100%; opacity: .2; filter: blur(2px);' class='img-fluid' src='advanced-options/raw-svg/regular/times-circle.svg'></div>";
    } else {
        echo "<div style='position: absolute; left: 5px; top: 25px; z-index: 99999 !important;'>" . $sawim . "</div><a class='imtrans' data-toggle='tooltip' data-placement='auto' title='", $row['Movie_Title'], " movie details.'  href='index.php?pid=minfo&Movie_Id=", $row['Movie_Id'], "'><img class='img-fluid coverim' src='movieims/", $row['Movie_Image'], "' style='margin-bottom: 4px; height: 100%;'></a><br>";
    }
    ?>

                <a class="tbuttonsm" data-toggle="tooltip" data-placement="auto" title=" View <?php echo $row['Movie_Title'] ?> Info on Google." href="https://www.google.com/search?q=<?php echo $addtoo, '+' ,  $row['Release_Year']?>" target="_blank"><b>  <?php echo $row['Movie_Title'] ?> </b></a>
            </div>
        </div>

    <?php
    //The number of columns will be 1 larger than the default $i == ? value.
    //As shown, this value is 3 giving 4 columns. 2 will give 3 columns etc.
    //The default uses Bootstrap so the col values will need changed above.

    if ($i == 3) {
        $i = 0;
        echo "</div>";
    } else {
        $i++;
    }
}
?>

</div>
    <?php include 'includes/pagination_inc.php'; ?>