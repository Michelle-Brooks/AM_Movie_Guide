<?php
//////////////////////////////////////////////////////////////////////
//                                                                  //
//   Copyright: Appplebite Media. (except where noted)              //
//   Author: Michelle Brooks (except where noted)                   //
//   Contact: http://www.applebitemedia.com/index.php?pid=contact   // 
//                                                                  //
//////////////////////////////////////////////////////////////////////

if (!$username = Input::get('user')) {
    Session::flash('home', 'You must be logged in to go there!');
    Redirect::to('index.php');
} else {
    $user = new User($username);

    if (!$user->exists()) {
        Redirect::to(404);
    } else {
        $data = $user->data();
    }
    ?>
    <div class="container" style="display: block; text-align: left; min-height: 360px;">
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-4">
                <h3><?php echo ucwords(escape($data->username)); ?></h3>
                <p>Real Name: <?php echo escape($data->your_name); ?></p>
            </div>
            <div class="col-sm-4">
                <ul  class="fa-ul">
                    <li><span class="fa-li"><i class="fas fa-unlock-alt"></i></span> <a href="logout.php">Log Out</a></li>
                    <li><span class="fa-li"><i class="fas fa-info-circle"></i></span> <a href="index.php?pid=mupd">Update Your Info</a></li>
                    <li><span class="fa-li"><i class="fas fa-pen-square"></i></span> <a href="index.php?pid=cpas">Change Your Password</a></li>
                </ul>
            </div>
            <div class="col-sm-2"></div>
        </div>
    </div>
    <?php
}
?>