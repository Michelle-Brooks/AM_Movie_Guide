<?php
//////////////////////////////////////////////////////////////////////
//                                                                  //
//   Copyright: Appplebite Media. (except where noted)              //
//   Author: Michelle Brooks (except where noted)                   //
//   Contact: http://www.applebitemedia.com/index.php?pid=contact   // 
//                                                                  //
//////////////////////////////////////////////////////////////////////

if (Input::exists()) {
    if (Token::check(Input::get('token'))) {
        $validate = new Validate();
        $validation = $validate->check($_POST, array(
            'username' => array('required' => true),
            'password' => array('required' => true)
        ));
        if ($validation->passed()) {
            $user = new User();
            $remember = (Input::get('remember') === 'on') ? true : false;
            $login = $user->login(Input::get('username'), Input::get('password'), $remember);

            if ($login) {
                Redirect::to('index.php');
            } else {
                echo 'Logging in falied.';
            }
        } else {
            ?>
            <div class="container" style="display: inline-block; color: yellow;">
                <div align="center">
                    <?php
                    foreach ($validation->errors() as $error) {
                        echo $error, '<br>';
                    }
                    ?>
                </div>
            </div>
            <?php
        }
    }
}
?>
<div class="container" style="display: block;">
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-md-6">
            <h3>Enter your username and password below.</h3>
            <br><br>
            <form method="POST" action="">
                <div class="form-group">
                    <div class="field">
                        <label for="username">Username</label>
                        <input class="form-control form-control-sm" type="text" id="username" name="username" autocomplete="off" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="field">
                        <label for="password">Password</label>
                        <input class="form-control form-control-sm" type="password" id="password" name="password" autocomplete="off" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="field">
                        <label for="remember">
                            <input type="checkbox" name="remember" id="remember"> Remember me.
                        </label>
                    </div>
                </div>
                <div class="form-group">
                    <input type="hidden" name="token" value="<?php echo Token::generate(); ?>" />
                    <input class="btn btn-outline-secondary btn-sm" type="submit" value="Log In" name="submit" />
                </div>

            </form>
        </div>
        <div class="col-sm-3"></div>
    </div>
</div>
<br><br>