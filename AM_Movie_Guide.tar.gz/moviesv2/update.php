<?php
//////////////////////////////////////////////////////////////////////
//                                                                  //
//   Copyright: Appplebite Media. (except where noted)              //
//   Author: Michelle Brooks (except where noted)                   //
//   Contact: http://www.applebitemedia.com/index.php?pid=contact   // 
//                                                                  //
//////////////////////////////////////////////////////////////////////


$user = new User();


if (!$user->isLoggedIn()) {
    Session::flash('home', 'You must be logged in to do that!');
    Redirect::to('index.php');
}

if (Input::exists()) {
    if (Token::check(Input::get('token'))) {
        $validate = new Validate();
        $validation = $validate->check($_POST, array(
            'your_name' => array(
                'label' => 'Your Name',
                'required' => true,
                'min' => 2,
                'max' => 50
            )
        ));

        if ($validation->passed()) {
            
            
            try {
                
                $whereid = 'userid';           
                $tableid = $user->data()->userid;
                
                $user->update(array(
                    
                    'your_name' => Input::get('your_name')
                    
                ), $whereid, $tableid);
                
                Session::flash('home', 'Your information has been updated.');
                Redirect::to('index.php');
            } catch (Exception $e) {

                die($e->getMessage());
            }
        } else {
            foreach ($validation->errors() as $error) {
                echo $error, '<br>';
            }
        }
    }
}
?>

<div class="container" style="display: block; text-align: left; min-height: 360px;">
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <form name="update" method="POST" enctype="multipart/form-data" action="">
                <div class="form-row">
                    <label for="your_name">Your Name</label>
                    <input class="form-control form-control-sm" type="text" name="your_name" id="your_name" value="<?php echo escape($user->data()->your_name); ?>">
                </div>
                <br>
                <div class="form-row">
                    <input type="hidden" name="token" id="token" value="<?php echo Token::generate(); ?>">
                    <input class="btn btn-outline-secondary btn-sm" type="submit" value="Update">
                </div>

            </form>
        </div>
        <div class="col-sm-3"></div>
    </div>
</div>