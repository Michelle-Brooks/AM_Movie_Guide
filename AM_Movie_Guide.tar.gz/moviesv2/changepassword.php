<?php
//////////////////////////////////////////////////////////////////////
//                                                                  //
//   Copyright: Appplebite Media. (except where noted)              //
//   Author: Michelle Brooks (except where noted)                   //
//   Contact: http://www.applebitemedia.com/index.php?pid=contact   // 
//                                                                  //
//////////////////////////////////////////////////////////////////////

$user = new User();

if (!$user->isLoggedIn()) {
    Session::flash('home', 'You must be logged in to do that!');
    Redirect::to('index.php');
}

if (Input::exists()) {
    if (Token::check(Input::get('token'))) {
        $validate = new Validate();
        $validation = $validate->check($_POST, array(
            'password_current' => array(
                'label' => '"Current Password" ',
                'required' => true,
                'min' => 6
            ),
            'password_new' => array(
                'label' => '"New Password" ',
                'required' => true,
                'min' => 6
            ),
            'password_new_again' => array(
                'label' => '"New Password Again" ',
                'required' => true,
                'min' => 6,
                'matches' => 'password_new'
            )
        ));

        if ($validation->passed()) {
            if (Hash::make(Input::get('password_current'), $user->data()->salt) !== $user->data()->password) {
                echo 'Your current password is wrong.';
            } else {
                $salt = Hash::salt(32);
                $user->update(array(
                    'password' => Hash::make(Input::get('password_new'), $salt),
                    'salt' => $salt
                ), $where = 'userid', $tableid = Input::get('userid') );

                Session::flash('home', 'Your password has been changed!');
                Redirect::to('index.php');
            }
        } else {
            foreach ($validation->errors() as $error) {
                echo $error, '<br>';
            }
        }
    }
}
?>

<div class="container" style="display: block; text-align: left; min-height: 360px;">
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <form name = "password_change" method = "POST" enctype = "multipart/form-data" action="">
                <div class="form-row">
                    <label for="password_current">Current Password</label>
                    <input class="form-control form-control-sm" type="password" name="password_current" id="password_current" value="" autocomplete="off" placeholder="Current Password">
                </div>
                <br>
                <div class="form-row">
                    <label for="password_new">New Password</label>
                    <input class="form-control form-control-sm" type="password" name="password_new" id="password" value="" autocomplete="off" placeholder="Password">
                </div>
                <br>
                <div class="form-row">
                    <label for="password">New Password Again</label>
                    <input class="form-control form-control-sm" type="password" name="password_new_again" id="password_new_again" value="" autocomplete="off" placeholder="Confirm Password">
                </div>
                <br>
                <div class="form-row">
                    <input type="hidden" name="userid" id="userid" value="<?php echo escape($user->data()->userid); ?>">
                    <input type="hidden" name="token" id="token" value="<?php echo Token::generate(); ?>">
                    <input class="btn btn-outline-secondary btn-sm" type="submit" value="Change Password">
                </div>
            </form>
        </div>
        <div class="col-sm-3"></div>
    </div>
</div>