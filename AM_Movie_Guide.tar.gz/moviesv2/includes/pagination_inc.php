<?php
//////////////////////////////////////////////////////////////////////
//                                                                  //
//   Copyright: Appplebite Media. (except where noted)              //
//   Author: Michelle Brooks (except where noted)                   //
//   Contact: http://www.applebitemedia.com/index.php?pid=contact   // 
//                                                                  //
//////////////////////////////////////////////////////////////////////
?>
<div class="container" style="border-top: 1px dotted #ddd; margin-top: 15px;">
    <center>
        <?php
        // Page navagation
        if (isset($page)) {

            $totalPages = ceil($gtotals / $perpage);
            echo "<div class='row'><div class='col-sm-1'>";
            if ($page <= 1) {
                echo "<span id='page_links' style='font-weight: bold; color: #ddd; padding: 4px; margin: 4px 2px;'> Prev </span>";
            } else {
                $j = $page - 1;
                echo "<span> <a id='page_a_link' href='index.php?mterm=$mterm&cterm=$cterm&tterm=$mterm&gterm=$cterm&gterm=$lterm&year=$yterm&md=$md&actor=$actorname&director=$directorname&new=$newest&watched=$seen&page=$j'>Prev</a> </span>";
            }
            echo "</div><div class='col-sm-10'>";
            for ($i = 1; $i <= $totalPages; $i++) {

                if ($i <> $page) {
                    echo "<span> <a id='page_a_link' href='index.php?mterm=$mterm&cterm=$cterm&tterm=$mterm&gterm=$cterm&gterm=$lterm&year=$yterm&md=$md&actor=$actorname&director=$directorname&new=$newest&watched=$seen&page=$i'>$i</a> </span>";
                } else {
                    echo "<span id='page_links' style='font-weight: bold; color: RED; margin: 3px;'> $i </span>";
                }
            }
            echo "</div><div class='col-sm-1'>";
            if ($page == $totalPages) {
                echo "  <span id='page_links' style='font-weight: bold; color: #ddd; padding: 4px; margin: 4px 2px;'> Next </span>";
            } else {
                $j = $page + 1;
                echo "  <span> <a id='page_a_link' href='index.php?mterm=$mterm&cterm=$cterm&tterm=$mterm&gterm=$cterm&gterm=$lterm&year=$yterm&md=$md&actor=$actorname&director=$directorname&new=$newest&watched=$seen&page=$j'>Next</a> </span>";
            }
            echo "</div></div>";
        }
        ?>               
    </center>

</div>