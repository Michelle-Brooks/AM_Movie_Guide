<?php
//////////////////////////////////////////////////////////////////////
//                                                                  //
//   Copyright: Appplebite Media. (except where noted)              //
//   Author: Michelle Brooks (except where noted)                   //
//   Contact: http://www.applebitemedia.com/index.php?pid=contact   // 
//                                                                  //
//////////////////////////////////////////////////////////////////////

$movieid = filter_input(INPUT_GET, 'Movie_Id');
$movie = new Movie($movieid);
$mid = filter_input(INPUT_GET, 'Movie_Id');
$addplus = preg_replace('/\s+/', '+', $movie->data()->Movie_Title);
$acast = str_replace("\r\n", "<br />", $movie->data()->Cast);
$dirby = addslashes(filter_input(INPUT_POST, 'Directed_By'));
$maindir = str_replace(' ', '_', $movie->data()->Main_Dir);

?>
<div class="container fade-in" style='margin-top: 35px; margin-bottom: 15px;'>
    <h1 style='margin-bottom: 50px;'><span class='highlight'><?php echo htmlspecialchars($movie->data()->Movie_Title, ENT_HTML5, 'UTF-8') ?></span>   (<?php echo $movie->data()->Release_Year ?>) <small><?php htmlspecialchars($movie->data()->Genre, ENT_HTML5, 'UTF-8') ?></small></h1>
    <div class="row">
        <div class="col-md-4">
            <img class='img-fluid' style="border-radius: 15px; border: 1px solid #ccc; padding: 8px;" src="movieims/<?php echo $movie->data()->Movie_Image ?>">
        </div>
        <div class="col-md-8">
            <p><?php 
            echo htmlspecialchars($movie->data()->About, ENT_HTML5, 'UTF-8') 
                    ?></p>
            <p class="highlight"><b>Directed by:</b><br>
            <blockquote style="padding-left: 15px; margin-top: 6px;">                
                <?php
                //Seperate data into rows.
                $drow = list($dir) = preg_split("/[,]/", $movie->data()->Directed_By);
                //Seperate and list the values from the row.
                if ($dir > "") {
                    echo '<ul>';
                    foreach ($drow as $director) {
                        list($DB) = preg_split("/[,]/", $director);
                        echo "<li><a style='font-size: 14px; margin-right: 10px;' href='http://www.google.com/search?q=" . $DB . "' data-toggle='tooltip' data-placement='auto' title=' Get more information about " . $DB . " on Google. ' target='_blank'><i class='fas fa-info-circle' style='font-size: 14px;'></i></a>      <a style='font-size: 14px;' href='index.php?director=" . $DB . "' data-toggle='tooltip' data-placement='auto' title=' List all " . $DB . " movies. '>" . $DB . "</a></li>";
                    }
                    echo '</ul>';
                } else {
                    echo 'Not Added Yet.';
                }
                ?>
            </blockquote>
            <span class='highlight'><b>Main Cast:</b></span><br>
            <blockquote style="padding-left: 15px; margin-top: 6px;">
                <?php
                //Seperate data into rows.
                $c_row = list($all) = explode("\n", $movie->data()->Cast);
                //Seperate and list the values from the row.
                echo '<ul>';
                foreach ($c_row as $cast) {
                    list($actor, $char) = preg_split("/[-]/", $cast);
                    if ($char == "") {
                        $char = "Not Added Yet.";
                    }
                    echo "<li><a style='font-size: 14px; margin-right: 10px;' href='http://www.google.com/search?q=" . $actor . "' data-toggle='tooltip' data-placement='auto' title=' Get more information about " . $actor . " on Google. ' target='_blank'><i class='fas fa-info-circle' style='font-size: 14px;'></i></a>       <a style='font-size: 14px;' href='index.php?actor=" . $actor . "' data-toggle='tooltip' data-placement='auto' title=' List all movies with:  " . $actor . " '>" . $actor . "</a>&nbsp;&nbsp;:&nbsp;&nbsp;" . $char . " </li>";
                }
                echo '</ul>';
                
                if(basename($_SERVER['PHP_SELF']) == 'index.php?pid=minfo&Movie_Id=' . $movieid .''){
                $GoBack = "";
                } else {
                $GoBack = htmlspecialchars($_SERVER['HTTP_REFERER']);
                }
                
                ?>
            </blockquote>
            <br>
            <a type='button' class='btn btn-outline-secondary btn-sm' data-toggle='tooltip' data-placement='auto' title=' Edit Movie Info ' href='index.php?pid=emov&Movie_Id=<?php echo $movie->data()->Movie_Id ?>'><i class='fas fa-plus-circle' style='font-size: 14px;'></i></a>
             - <a type='button' class='btn btn-outline-secondary btn-sm' data-toggle='tooltip' data-placement='auto' title=' List all movies released this year. ' href='index.php?year=<?php echo $movie->data()->Release_Year ?>'> <i class='far fa-calendar-alt' style='font-size: 14px;'></i> <?php echo $movie->data()->Release_Year ?></a>
             - <a type='button' class='btn btn-outline-secondary btn-sm' data-toggle='tooltip' data-placement='auto' title=' List all movies in this Genre. ' href='index.php?gterm=<?php echo $movie->data()->Genre ?>'> <i class='fas fa-film' style='font-size: 14px;'></i> <?php echo $movie->data()->Genre ?></a> - 
            <a type='button' class='btn btn-outline-secondary btn-sm' data-toggle='tooltip' data-placement='auto' title=' Search Google for more about <?php echo $movie->data()->Movie_Title ?>. ' href='https://www.google.com/search?q=<?php echo $addplus ?>+<?php echo $movie->data()->Release_Year ?>' target='_blank'> <i class='fas fa-search-plus' style='font-size: 14px;'></i> Search on Google.</a> -
            <a type='button'  class='btn btn-outline-secondary btn-sm' data-toggle='tooltip' data-placement='auto' title=' List all movies in ths folder. ' href='index.php?md=<?php echo $movie->data()->Main_Dir ?>'> <i class='fas fa-folder' style='font-size: 14px;'></i> <?php echo $movie->data()->Main_Dir ?></a>
             - <a type='button'  class='btn btn-outline-secondary btn-sm' data-toggle='tooltip' data-placement='auto' title=' Watch this movie. ' href='media/<?php echo $maindir . "/" . str_replace(' ', '_', $movie->data()->Filename) ?>'> <i class='fas fa-play' style='font-size: 14px;'></i> </a>
            <br><br><a href="<?php echo $GoBack ?>" class="btn btn-outline-secondary btn-lg" style="width: 100%;">- Back -</a>

        </div>
    </div>
</div>