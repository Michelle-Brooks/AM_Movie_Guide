<?php
//////////////////////////////////////////////////////////////////////
//                                                                  //
//   Copyright: Appplebite Media. (except where noted)              //
//   Author: Michelle Brooks (except where noted)                   //
//   Contact: http://www.applebitemedia.com/index.php?pid=contact   // 
//                                                                  //
//////////////////////////////////////////////////////////////////////

if ($user->isLoggedIn()) {

    if ($user->hasPermission('admin')) {
        $permm = 'You are an administrator!';
    } else {
        $permm = 'You do not have special permissions.';
    }
    ?>

    <div class="logbar" style="display: block; margin-right: 0; margin-bottom: -40px; padding-right: 15px; margin-top: 0px; text-align: right;">
        Hello <a href="index.php?pid=upro&user=<?php echo escape($user->data()->username); ?>"><?php echo ucwords(escape($user->data()->your_name)); ?></a> - <?php echo escape($permm); ?>
        - <a href="logout.php">Log Out</a>
    </div>

    <?php
} else {
    
        ?>

    <div class="logbar" style="display: block; margin-right: 0; margin-bottom: -40px; padding-right: 15px; margin-top: 0px; text-align: right;">
        You need to <a href="index.php?pid=login">log in</a> or <a href="index.php?pid=register">register</a>.
    </div>

    <?php
    
}
?>
